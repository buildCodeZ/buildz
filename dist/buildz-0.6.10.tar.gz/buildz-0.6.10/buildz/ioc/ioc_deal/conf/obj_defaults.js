{
    single: 1
    construct: {
        args: []
        maps: {}
    }
    prev_call: null
    sets: []
    call: null
    remove: null
    after_remove: null
}