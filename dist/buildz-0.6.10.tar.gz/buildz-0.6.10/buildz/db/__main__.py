#coding=utf-8
from . import runz
runz.main()