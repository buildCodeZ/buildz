#coding=utf-8
#author:
from .dirz import dirs, FileDeal
from .lsf import lists, search, searchd,searchs,_search
from .fio import fread, freads, fwrite, fwrites, read,reads,write,writes, makefdir, dirpath,makedir,removes, cover, fcover, sread, swrite
from .fhs import fhash, fhashs

__author__ = "Zzz, emails: 1174534295@qq.com, 1309458652@qq.com"
