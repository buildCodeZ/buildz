#coding=utf-8

__version__="0.4.91"

# 小号多
__author__ = "Zzz, emails: 1174534295@qq.com, 1309458652@qq.com"

from .argx import fetch as args
from .base import Base, WBase