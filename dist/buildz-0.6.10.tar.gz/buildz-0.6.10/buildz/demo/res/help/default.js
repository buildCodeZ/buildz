{
text=
r"""run 
    python -m buildz xf +h [+en]
or
    python -m buildz ioc +h [+en]
or
    python -m buildz search +h [+en]
or
    python -m buildz myers opt f1 f2 f_stp [+e/+t]
to see help
"""
text.en=
r"""run 
    python -m buildz xf +h [+en]
or
    python -m buildz ioc +h [+en]
or
    python -m buildz search +h [+en]
or
    python -m buildz myers opt f1 f2 f_stp [+e/+t]
to see help
"""
}